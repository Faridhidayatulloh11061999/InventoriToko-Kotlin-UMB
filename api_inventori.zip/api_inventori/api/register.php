<?php
include '../config/config.php';

ob_clean();
header("Content-Type: application/json");

// Pakai POST, BUKAN JSON
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password_plain = trim($_POST['password'] ?? '');

// Validasi
if (empty($name) || empty($email) || empty($password_plain)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Semua field wajib diisi!"
    ]);
    exit;
}

$password = password_hash($password_plain, PASSWORD_DEFAULT);

// Cek email
$stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt_check->bind_param("s", $email);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    http_response_code(409);
    echo json_encode([
        "success" => false,
        "message" => "Email sudah terdaftar!"
    ]);
    $stmt_check->close();
    $conn->close();
    exit;
}
$stmt_check->close();

// Insert
$stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $password);

if ($stmt->execute()) {
    http_response_code(201);
    echo json_encode([
        "success" => true,
        "message" => "Register berhasil!"
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Register gagal: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
?>