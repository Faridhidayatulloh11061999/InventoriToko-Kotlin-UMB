-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2025 at 03:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventori`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `price` double NOT NULL,
  `image_url` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `stock`, `price`, `image_url`) VALUES
(1, 'Mesin Cuci LG 7Kg Front Loading', 15, 3200000, ''),
(2, 'Kulkas Sharp 2 Pintu 220L', 10, 3500000, ''),
(3, 'Microwave Panasonic NN-ST34HM', 18, 1500000, ''),
(4, 'Kompor Gas Rinnai 2 Tungku', 40, 450000, ''),
(5, 'Blender Philips HR2056', 50, 350000, ''),
(6, 'Dispenser Miyako WD-185H', 25, 600000, ''),
(7, 'Rice Cooker Cosmos CRJ-3301', 60, 280000, ''),
(8, 'Vacuum Cleaner Electrolux EC41-6DB', 20, 1600000, ''),
(9, 'Kipas Angin Maspion F-167', 70, 300000, ''),
(10, 'Setrika Philips GC122', 80, 250000, ''),
(11, 'Toaster Kirin KST-365', 35, 320000, ''),
(12, 'Water Heater Ariston AN15R', 12, 1700000, ''),
(13, 'Pemanggang Roti Oxone OX-833', 30, 290000, ''),
(14, 'Oven Listrik Mito MO-777', 14, 1200000, ''),
(15, 'Slow Cooker Miyako SC-400', 20, 500000, ''),
(16, 'Juicer Sharp EJ-C20Y-RD', 22, 880000, ''),
(17, 'Air Purifier Sharp FP-J30Y-A', 18, 1700000, ''),
(18, 'Alat Pel Lantai Spin Mop Bolde', 45, 150000, ''),
(19, 'Dispenser Sabun Otomatis Xiaomi', 55, 170000, ''),
(20, 'Sikat Gigi Elektrik Oral-B Vitality', 60, 400000, '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$CzZdBxuJDYWk6Mzn4HoNi.ZDt4nx49a8HY9fb2.avNDgrUsdHBhSG'),
(2, '', '', '$2y$10$MIX/ChfOqDGvRx/DyNsPyuGWM8NDDEmzXkrd8mWEBqpEVVg/SqMqy'),
(7, 'user', 'user@gmail.com', '$2y$10$2iCpqCNfzsZaqtd1a2YYQ.q4WpovZx58GEP5nFGAN4aAWsH7a.lY6'),
(8, 'farid', 'farid@gmail.com', '$2y$10$ITInXKMj6mzNf44A.w/YdeZZM6LVb9QJNuEtPj4YB2gcqr0RGFp3m');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
